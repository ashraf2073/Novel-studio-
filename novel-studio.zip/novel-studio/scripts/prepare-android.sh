#!/usr/bin/env bash
# Novel Studio — prepares the Android project — made par ashraf
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== Bundling libraries for offline use"
mkdir -p www/vendor
curl -fsSL https://cdn.tailwindcss.com/3.4.17 -o www/vendor/tailwind.js
curl -fsSL https://cdnjs.cloudflare.com/ajax/libs/lucide/0.263.1/lucide.min.js -o www/vendor/lucide.js
curl -fsSL https://cdnjs.cloudflare.com/ajax/libs/localforage/1.10.0/localforage.min.js -o www/vendor/localforage.js
sed -i 's#https://cdn.tailwindcss.com/3.4.17#vendor/tailwind.js#;s#https://cdnjs.cloudflare.com/ajax/libs/lucide/0.263.1/lucide.min.js#vendor/lucide.js#;s#https://cdnjs.cloudflare.com/ajax/libs/localforage/1.10.0/localforage.min.js#vendor/localforage.js#' www/index.html

echo "== Android platform"
[ -d android ] || npx cap add android

echo "== App icon and splash screen"
npx capacitor-assets generate --android --iconBackgroundColor '#0d0d11' --iconBackgroundColorDark '#0d0d11' --splashBackgroundColor '#0d0d11' --splashBackgroundColorDark '#0d0d11' || echo "Icon generation skipped"

echo "== Manifest: microphone and speech service"
M=android/app/src/main/AndroidManifest.xml
grep -q RECORD_AUDIO "$M" || sed -i 's#<application#<uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>\n    <application#' "$M"

echo "== Sync"
npx cap sync android
