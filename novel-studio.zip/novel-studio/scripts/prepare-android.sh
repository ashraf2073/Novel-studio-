#!/usr/bin/env bash
# Novel Studio — prepares the Android project — made par ashraf
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== Bundling libraries for offline use (from npm, no CDN needed)"
mkdir -p www/vendor
cp node_modules/lucide/dist/umd/lucide.min.js www/vendor/lucide.js
cp node_modules/localforage/dist/localforage.min.js www/vendor/localforage.js
printf '@tailwind base;\n@tailwind components;\n@tailwind utilities;\n' > /tmp/tw-in.css
npx tailwindcss -i /tmp/tw-in.css -o www/vendor/tailwind.css --content './www/index.html' --minify
sed -i 's#<script src="https://cdn.tailwindcss.com/3.4.17"></script>#<link rel="stylesheet" href="vendor/tailwind.css">#;s#https://cdn.jsdelivr.net/npm/lucide@1.53.0/dist/umd/lucide.min.js#vendor/lucide.js#;s#https://cdn.jsdelivr.net/npm/localforage@1.10.0/dist/localforage.min.js#vendor/localforage.js#' www/index.html
grep -q 'vendor/tailwind.css' www/index.html && grep -q 'vendor/lucide.js' www/index.html && grep -q 'vendor/localforage.js' www/index.html || { echo "Offline bundling failed"; exit 1; }

echo "== Android platform"
[ -d android ] || npx cap add android

echo "== App icon and splash screen"
npx capacitor-assets generate --android --iconBackgroundColor '#0d0d11' --iconBackgroundColorDark '#0d0d11' --splashBackgroundColor '#0d0d11' --splashBackgroundColorDark '#0d0d11' || echo "Icon generation skipped"

echo "== Manifest: microphone and speech service"
M=android/app/src/main/AndroidManifest.xml
grep -q RECORD_AUDIO "$M" || sed -i 's#<application#<uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>\n    <application#' "$M"

echo "== Sync"
npx cap sync android
