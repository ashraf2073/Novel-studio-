-- Novel Studio cloud backup tables — made par ashraf
-- Paste all of this into Supabase: SQL Editor > New query > Run
create table if not exists public.novel_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.novel_data enable row level security;
drop policy if exists "read own data" on public.novel_data;
drop policy if exists "insert own data" on public.novel_data;
drop policy if exists "update own data" on public.novel_data;
drop policy if exists "delete own data" on public.novel_data;
create policy "read own data" on public.novel_data for select to authenticated using (auth.uid() = user_id);
create policy "insert own data" on public.novel_data for insert to authenticated with check (auth.uid() = user_id);
create policy "update own data" on public.novel_data for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "delete own data" on public.novel_data for delete to authenticated using (auth.uid() = user_id);
