// Novel Studio cloud settings — public values only. Never put a secret or service_role key here.
// made par ashraf
window.NS_CLOUD={url:'https://cjlzguutmbeajlrcuonr.supabase.co',key:'sb_publishable_KbpiGlBs5iB0hQCt3pHCOw_UHBAOttK'};
