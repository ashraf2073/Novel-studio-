# Novel Studio — made par ashraf

Offline-first novel composer (PWA + Capacitor Android app). Everything saves on the device first.

## Build the APK without a computer (GitHub Actions)
1. Upload `novel-studio.zip` to the root of a GitHub repo and keep `.github/workflows/android.yml` in it.
2. Run **Actions > Build Android APK**, then download `novel-studio-apk` from the run's Artifacts.
3. Builds are signed with the key in `keystore/`, so new APKs install over the old app and keep your data. (Only the first install after switching to this key needs an uninstall. This is a debug key: fine for personal use, not for the Play Store.)

## Cloud backup and accounts (optional, free, no Google)
The app talks to a free Supabase project that you own.
1. Create a free project at supabase.com.
2. **SQL Editor > New query**: paste `cloud/supabase-setup.sql` and run it.
3. **Authentication > Providers > Email**: turn off "Confirm email" (simplest for personal use).
4. **Project Settings > API**: copy the *Project URL* and the *anon / publishable* key.
5. In the app: menu > **Account & backup**: paste both, Save, then **Create account**.

Sync runs automatically a few seconds after you stop typing, when the app opens, and when you tap Sync now. If both the phone and the cloud changed, the app asks which version to keep and stores a safety copy (Restore previous copy). Password reset by email is not built in yet, so also use **Export backup** now and then.

## Build locally
`npm install && bash scripts/prepare-android.sh && npx cap open android`

## Notes
- `scripts/prepare-android.sh` bundles Tailwind/Lucide/LocalForage for offline use, makes the icon and splash from `assets/`, adds the microphone permission and applies the signing key.
- Voice input uses `@capacitor-community/speech-recognition` on Android and the Web Speech API in browsers.
- The AI composer is rule-based and works offline. Swap the `AI` object in `www/index.html` for an LLM API call for smarter output.
- In the APK, exports open the Android share sheet. For PDF, share the HTML file, open it in Chrome and use Print > Save as PDF.
