# Novel Studio — made par ashraf

Offline-first novel composer (PWA + Capacitor).

## Run as PWA
`npx serve www` then open in Chrome and "Install app".

## Build the Android APK
```
npm install
npx cap add android
npx cap sync android
npx cap open android      # Build > Build APK(s) in Android Studio
```
## Notes
- **Fully offline APK:** download tailwind (build with its CLI), lucide, localforage into `www/vendor/` and point the three `<script>` tags there. The CDN copies are cached by the service worker after first run.
- **Voice in the APK:** Android WebView has no Web Speech API. Add `@capacitor-community/speech-recognition` (already in package.json) and add `RECORD_AUDIO` permission in AndroidManifest.xml.
- **Exports in the APK:** browser downloads don't save in WebView; swap `dl()` in index.html for `@capacitor/filesystem` + `@capacitor/share`.
- **AI:** the composer runs locally with rule-based heuristics (no network). Replace the functions in the `AI` object with calls to an LLM endpoint for smarter output.
