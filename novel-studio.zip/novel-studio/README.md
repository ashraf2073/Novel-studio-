# Novel Studio — made par ashraf

Offline-first novel composer (PWA + Capacitor Android app).

## Build the APK without a computer (GitHub Actions)
1. Upload `novel-studio.zip` to the root of a GitHub repo and put `.github/workflows/android.yml` in it.
2. Run **Actions → Build Android APK**, then download `novel-studio-apk` from the run's Artifacts.
3. Uninstall any older copy before installing (each cloud build is signed with a new debug key).

## Build locally
`npm install && bash scripts/prepare-android.sh && npx cap open android`

## Notes
- `scripts/prepare-android.sh` bundles Tailwind/Lucide/LocalForage for offline use, generates the icon and splash from `assets/`, and adds microphone permission.
- Voice input uses `@capacitor-community/speech-recognition` on Android and the Web Speech API in browsers.
- The AI composer is rule-based and runs offline. Swap the `AI` object in `www/index.html` for an LLM API call for smarter output.
- Exports use browser downloads; for saving files from the APK, add `@capacitor/filesystem` + `@capacitor/share`.
